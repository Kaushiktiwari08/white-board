import React, { useState } from 'react';
import { 
  Pen, 
  Eraser,
  Square,
  Circle,
  Highlighter,
  Palette,
  Undo,
  Redo,
  Minimize,
  Trash2,
  Grid,
  Sun,
  Moon,
  Type
} from 'lucide-react';
import { Tool } from '../types';

interface FullscreenToolbarProps {
  tool: Tool;
  onToolChange: (tool: Tool) => void;
  onUndo: () => void;
  onRedo: () => void;
  onClear: () => void;
  onBackgroundChange: (bg: 'white' | 'black' | 'grid') => void;
  canUndo: boolean;
  canRedo: boolean;
  currentBackground: 'white' | 'black' | 'grid';
  onExitFullscreen: () => void;
}

const colors = [
  '#ffffff', '#f8fafc', '#dc2626', '#ea580c', '#d97706', '#65a30d',
  '#059669', '#0891b2', '#2563eb', '#7c3aed', '#c026d3', '#e11d48'
];

const brushSizes = [1, 2, 4, 8, 12, 16];

export const FullscreenToolbar: React.FC<FullscreenToolbarProps> = ({
  tool,
  onToolChange,
  onUndo,
  onRedo,
  onClear,
  onBackgroundChange,
  canUndo,
  canRedo,
  currentBackground,
  onExitFullscreen
}) => {
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showBrushSizes, setShowBrushSizes] = useState(false);

  const toolButtons = [
    { type: 'pen', icon: Pen, label: 'Pen' },
    { type: 'highlighter', icon: Highlighter, label: 'Highlighter' },
    { type: 'eraser', icon: Eraser, label: 'Eraser' },
    { type: 'text', icon: Type, label: 'Text' },
    { type: 'rectangle', icon: Square, label: 'Rectangle' },
    { type: 'circle', icon: Circle, label: 'Circle' }
  ];

  const backgroundButtons = [
    { type: 'white', icon: Sun, label: 'White' },
    { type: 'black', icon: Moon, label: 'Black' },
    { type: 'grid', icon: Grid, label: 'Grid' }
  ];

  return (
    <div className="fixed left-4 top-1/2 transform -translate-y-1/2 z-50">
      <div className="bg-gradient-to-b from-gray-900 via-black to-gray-900 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700/50 p-2 space-y-1.5 min-w-[56px]">
        {/* Subtle glow effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-blue-500/10 rounded-2xl blur-lg -z-10"></div>
        
        {/* Tool Buttons */}
        <div className="space-y-1.5">
          {toolButtons.map(({ type, icon: Icon, label }) => (
            <button
              key={type}
              onClick={() => onToolChange({ 
                ...tool, 
                type: type as Tool['type'],
                width: type === 'highlighter' ? 12 : tool.width,
                color: type === 'highlighter' ? '#22c55e' : tool.color
              })}
              className={`group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 ${
                tool.type === type
                  ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30 ring-2 ring-blue-400/50'
                  : 'bg-gray-800/60 hover:bg-gray-700/80 text-gray-300 hover:text-white border border-gray-600/30 hover:border-gray-500/50'
              }`}
              title={label}
            >
              <Icon size={16} className="drop-shadow-sm" />
              {tool.type === type && (
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-blue-600/20 rounded-xl animate-pulse"></div>
              )}
            </button>
          ))}
        </div>

        {/* Elegant Divider */}
        <div className="relative py-1.5">
          <div className="h-px bg-gradient-to-r from-transparent via-gray-600 to-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-gray-600 rounded-full"></div>
          </div>
        </div>

        {/* Color Picker */}
        <div className="relative">
          <button
            onClick={() => setShowColorPicker(!showColorPicker)}
            className="group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 bg-gray-800/60 hover:bg-gray-700/80 border border-gray-600/30 hover:border-gray-500/50"
            title="Color"
          >
            <Palette size={16} className="text-gray-300 group-hover:text-white drop-shadow-sm" />
            <div 
              className="absolute bottom-1 right-1 w-2.5 h-2.5 rounded-full border-2 border-gray-800 shadow-lg ring-1 ring-white/20"
              style={{ backgroundColor: tool.color }}
            />
          </button>
          
          {showColorPicker && (
            <div className="absolute left-full ml-2 top-0 bg-gradient-to-b from-gray-900 to-black rounded-xl shadow-2xl border border-gray-700/50 p-2 backdrop-blur-xl">
              <div className="grid grid-cols-3 gap-1.5 w-24">
                {colors.map((color) => (
                  <button
                    key={color}
                    onClick={() => {
                      onToolChange({ ...tool, color });
                      setShowColorPicker(false);
                    }}
                    className={`w-6 h-6 rounded-lg border-2 transition-all duration-300 transform hover:scale-110 shadow-lg ${
                      tool.color === color 
                        ? 'border-blue-400 ring-2 ring-blue-400/50 scale-110' 
                        : 'border-gray-600/50 hover:border-gray-400/70'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Brush Size */}
        <div className="relative">
          <button
            onClick={() => setShowBrushSizes(!showBrushSizes)}
            className="group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 bg-gray-800/60 hover:bg-gray-700/80 border border-gray-600/30 hover:border-gray-500/50"
            title="Brush Size"
          >
            <div 
              className="rounded-full bg-gradient-to-r from-gray-300 to-white shadow-lg"
              style={{ 
                width: `${Math.min(tool.width + 2, 12)}px`, 
                height: `${Math.min(tool.width + 2, 12)}px` 
              }}
            />
          </button>
          
          {showBrushSizes && (
            <div className="absolute left-full ml-2 top-0 bg-gradient-to-b from-gray-900 to-black rounded-xl shadow-2xl border border-gray-700/50 p-2 backdrop-blur-xl">
              <div className="space-y-2">
                {brushSizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => {
                      onToolChange({ ...tool, width: size });
                      setShowBrushSizes(false);
                    }}
                    className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-300 transform hover:scale-110 ${
                      tool.width === size 
                        ? 'bg-gradient-to-r from-blue-500 to-blue-600 ring-2 ring-blue-400/50' 
                        : 'bg-gray-800/60 hover:bg-gray-700/80 border border-gray-600/30'
                    }`}
                  >
                    <div 
                      className={`rounded-full shadow-sm ${
                        tool.width === size ? 'bg-white' : 'bg-gradient-to-r from-gray-300 to-white'
                      }`}
                      style={{ width: `${size + 1}px`, height: `${size + 1}px` }}
                    />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Elegant Divider */}
        <div className="relative py-1.5">
          <div className="h-px bg-gradient-to-r from-transparent via-gray-600 to-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-gray-600 rounded-full"></div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-1.5">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className={`group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 ${
              canUndo 
                ? 'bg-gray-800/60 hover:bg-gray-700/80 text-gray-300 hover:text-white border border-gray-600/30 hover:border-gray-500/50' 
                : 'bg-gray-900/40 text-gray-600 cursor-not-allowed border border-gray-700/20'
            }`}
            title="Undo"
          >
            <Undo size={16} className="drop-shadow-sm" />
          </button>

          <button
            onClick={onRedo}
            disabled={!canRedo}
            className={`group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 ${
              canRedo 
                ? 'bg-gray-800/60 hover:bg-gray-700/80 text-gray-300 hover:text-white border border-gray-600/30 hover:border-gray-500/50' 
                : 'bg-gray-900/40 text-gray-600 cursor-not-allowed border border-gray-700/20'
            }`}
            title="Redo"
          >
            <Redo size={16} className="drop-shadow-sm" />
          </button>

          <button
            onClick={onClear}
            className="group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 bg-gray-800/60 hover:bg-red-900/60 text-gray-300 hover:text-red-400 border border-gray-600/30 hover:border-red-500/50"
            title="Clear Page"
          >
            <Trash2 size={16} className="drop-shadow-sm" />
          </button>
        </div>

        {/* Elegant Divider */}
        <div className="relative py-1.5">
          <div className="h-px bg-gradient-to-r from-transparent via-gray-600 to-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-gray-600 rounded-full"></div>
          </div>
        </div>

        {/* Background Options */}
        <div className="space-y-1.5">
          {backgroundButtons.map(({ type, icon: Icon, label }) => (
            <button
              key={type}
              onClick={() => onBackgroundChange(type as 'white' | 'black' | 'grid')}
              className={`group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 ${
                currentBackground === type
                  ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/30 ring-2 ring-purple-400/50'
                  : 'bg-gray-800/60 hover:bg-gray-700/80 text-gray-300 hover:text-white border border-gray-600/30 hover:border-gray-500/50'
              }`}
              title={label}
            >
              <Icon size={16} className="drop-shadow-sm" />
              {currentBackground === type && (
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 to-purple-600/20 rounded-xl animate-pulse"></div>
              )}
            </button>
          ))}
        </div>

        {/* Elegant Divider */}
        <div className="relative py-1.5">
          <div className="h-px bg-gradient-to-r from-transparent via-gray-600 to-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-gray-600 rounded-full"></div>
          </div>
        </div>

        {/* Exit Fullscreen */}
        <button
          onClick={onExitFullscreen}
          className="group relative w-12 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 bg-gray-800/60 hover:bg-gray-700/80 text-gray-300 hover:text-white border border-gray-600/30 hover:border-gray-500/50"
          title="Exit Fullscreen"
        >
          <Minimize size={16} className="drop-shadow-sm" />
        </button>
      </div>
    </div>
  );
};