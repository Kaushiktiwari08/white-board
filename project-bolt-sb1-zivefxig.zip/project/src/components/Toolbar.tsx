import React, { useState } from 'react';
import { 
  Pen, 
  Eraser, 
  Square, 
  Circle, 
  Undo, 
  Redo, 
  Palette,
  Trash2,
  Grid,
  Sun,
  Moon,
  Highlighter,
  Type
} from 'lucide-react';
import { Tool } from '../types';

interface ToolbarProps {
  tool: Tool;
  onToolChange: (tool: Tool) => void;
  onUndo: () => void;
  onRedo: () => void;
  onClear: () => void;
  onBackgroundChange: (bg: 'white' | 'black' | 'grid') => void;
  canUndo: boolean;
  canRedo: boolean;
  currentBackground: 'white' | 'black' | 'grid';
}

const colors = [
  '#000000', '#374151', '#dc2626', '#ea580c', '#d97706', '#65a30d',
  '#059669', '#0891b2', '#2563eb', '#7c3aed', '#c026d3', '#e11d48'
];

const brushSizes = [1, 2, 4, 8, 12, 16];

export const Toolbar: React.FC<ToolbarProps> = ({
  tool,
  onToolChange,
  onUndo,
  onRedo,
  onClear,
  onBackgroundChange,
  canUndo,
  canRedo,
  currentBackground
}) => {
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showBrushSizes, setShowBrushSizes] = useState(false);

  const toolButtons = [
    { type: 'pen', icon: Pen, label: 'Pen' },
    { type: 'highlighter', icon: Highlighter, label: 'Highlighter' },
    { type: 'eraser', icon: Eraser, label: 'Eraser' },
    { type: 'text', icon: Type, label: 'Text' },
    { type: 'rectangle', icon: Square, label: 'Rectangle' },
    { type: 'circle', icon: Circle, label: 'Circle' }
  ];

  const backgroundButtons = [
    { type: 'white', icon: Sun, label: 'White' },
    { type: 'black', icon: Moon, label: 'Black' },
    { type: 'grid', icon: Grid, label: 'Grid' }
  ];

  return (
    <div className="fixed left-2 md:left-4 top-1/2 transform -translate-y-1/2 z-50">
      <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border border-gray-200 p-2 space-y-1">
        {/* Tool Buttons */}
        {toolButtons.map(({ type, icon: Icon, label }) => (
          <button
            key={type}
            onClick={() => onToolChange({ 
              ...tool, 
              type: type as Tool['type'],
              width: type === 'highlighter' ? 12 : tool.width,
              color: type === 'highlighter' ? '#22c55e' : tool.color
            })}
            className={`w-12 h-8 md:w-14 md:h-9 rounded-md flex items-center justify-center transition-all duration-200 group relative touch-manipulation ${
              tool.type === type
                ? 'bg-blue-500 text-white shadow-lg'
                : 'bg-gray-50 hover:bg-gray-100 text-gray-700 hover:text-gray-900'
            }`}
            title={label}
            style={{ WebkitTapHighlightColor: 'transparent' }}
          >
            <Icon size={14} className="w-3.5 h-3.5" />
          </button>
        ))}

        {/* Divider */}
        <div className="h-px bg-gray-200 mx-2" />

        {/* Color Picker */}
        <div className="relative">
          <button
            onClick={() => setShowColorPicker(!showColorPicker)}
            className="w-12 h-8 md:w-14 md:h-9 rounded-md flex items-center justify-center transition-all duration-200 bg-gray-50 hover:bg-gray-100 relative touch-manipulation"
            title="Color"
            style={{ WebkitTapHighlightColor: 'transparent' }}
          >
            <Palette size={14} className="text-gray-700 w-3.5 h-3.5" />
            <div 
              className="absolute bottom-0.5 right-1 w-2.5 h-2.5 rounded-full border border-white shadow-sm"
              style={{ backgroundColor: tool.color }}
            />
          </button>
          
          {showColorPicker && (
            <div className="absolute left-full ml-2 top-0 bg-white rounded-lg shadow-lg border border-gray-200 p-2">
              <div className="grid grid-cols-3 gap-1.5 w-24">
                {colors.map((color) => (
                  <button
                    key={color}
                    onClick={() => {
                      onToolChange({ ...tool, color });
                      setShowColorPicker(false);
                    }}
                    className={`w-6 h-6 rounded-md border-2 transition-all duration-200 touch-manipulation ${
                      tool.color === color ? 'border-blue-500 scale-105' : 'border-gray-200 hover:border-gray-300'
                    }`}
                    style={{ backgroundColor: color, WebkitTapHighlightColor: 'transparent' }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Brush Size */}
        <div className="relative">
          <button
            onClick={() => setShowBrushSizes(!showBrushSizes)}
            className="w-12 h-8 md:w-14 md:h-9 rounded-md flex items-center justify-center transition-all duration-200 bg-gray-50 hover:bg-gray-100 touch-manipulation"
            title="Brush Size"
            style={{ WebkitTapHighlightColor: 'transparent' }}
          >
            <div 
              className="rounded-full bg-gray-700"
              style={{ 
                width: `${Math.min(tool.width + 2, 12)}px`, 
                height: `${Math.min(tool.width + 2, 12)}px` 
              }}
            />
          </button>
          
          {showBrushSizes && (
            <div className="absolute left-full ml-2 top-0 bg-white rounded-lg shadow-lg border border-gray-200 p-2">
              <div className="space-y-2">
                {brushSizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => {
                      onToolChange({ ...tool, width: size });
                      setShowBrushSizes(false);
                    }}
                    className={`w-8 h-8 rounded-md flex items-center justify-center transition-all duration-200 touch-manipulation ${
                      tool.width === size ? 'bg-blue-500' : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                    style={{ WebkitTapHighlightColor: 'transparent' }}
                  >
                    <div 
                      className={`rounded-full ${tool.width === size ? 'bg-white' : 'bg-gray-700'}`}
                      style={{ width: `${size}px`, height: `${size}px` }}
                    />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Divider */}
        <div className="h-px bg-gray-200 mx-2" />

        {/* Undo/Redo */}
        <button
          onClick={onUndo}
          disabled={!canUndo}
          className={`w-12 h-8 md:w-14 md:h-9 rounded-md flex items-center justify-center transition-all duration-200 touch-manipulation ${
            canUndo 
              ? 'bg-gray-50 hover:bg-gray-100 text-gray-700 hover:text-gray-900' 
              : 'bg-gray-50 text-gray-400 cursor-not-allowed'
          }`}
          title="Undo"
          style={{ WebkitTapHighlightColor: 'transparent' }}
        >
          <Undo size={14} className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={onRedo}
          disabled={!canRedo}
          className={`w-12 h-8 md:w-14 md:h-9 rounded-md flex items-center justify-center transition-all duration-200 touch-manipulation ${
            canRedo 
              ? 'bg-gray-50 hover:bg-gray-100 text-gray-700 hover:text-gray-900' 
              : 'bg-gray-50 text-gray-400 cursor-not-allowed'
          }`}
          title="Redo"
          style={{ WebkitTapHighlightColor: 'transparent' }}
        >
          <Redo size={14} className="w-3.5 h-3.5" />
        </button>

        {/* Clear */}
        <button
          onClick={onClear}
          className="w-12 h-8 md:w-14 md:h-9 rounded-md flex items-center justify-center transition-all duration-200 bg-gray-50 hover:bg-red-50 text-gray-700 hover:text-red-600 touch-manipulation"
          title="Clear Page"
          style={{ WebkitTapHighlightColor: 'transparent' }}
        >
          <Trash2 size={14} className="w-3.5 h-3.5" />
        </button>

        {/* Divider */}
        <div className="h-px bg-gray-200 mx-2" />

        {/* Background Options */}
        {backgroundButtons.map(({ type, icon: Icon, label }) => (
          <button
            key={type}
            onClick={() => onBackgroundChange(type as 'white' | 'black' | 'grid')}
            className={`w-12 h-8 md:w-14 md:h-9 rounded-md flex items-center justify-center transition-all duration-200 touch-manipulation ${
              currentBackground === type
                ? 'bg-blue-500 text-white shadow-lg'
                : 'bg-gray-50 hover:bg-gray-100 text-gray-700 hover:text-gray-900'
            }`}
            title={label}
            style={{ WebkitTapHighlightColor: 'transparent' }}
          >
            <Icon size={14} className="w-3.5 h-3.5" />
          </button>
        ))}
      </div>
    </div>
  );
};