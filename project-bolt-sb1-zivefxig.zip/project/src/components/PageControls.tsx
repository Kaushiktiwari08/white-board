import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PageControlsProps {
  isFullscreen: boolean;
  currentPage: number;
  onPreviousPage: () => void;
  onNextPage: () => void;
}

export const PageControls: React.FC<PageControlsProps> = ({
  isFullscreen,
  currentPage,
  onPreviousPage,
  onNextPage
}) => {
  if (!isFullscreen) return null;

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50">
      <div className="bg-gradient-to-r from-gray-900 via-black to-gray-900 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700/50 px-4 py-3">
        {/* Subtle glow effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-blue-500/10 rounded-2xl blur-lg -z-10"></div>
        
        <div className="flex items-center space-x-3">
          {/* Previous Page */}
          <button
            onClick={onPreviousPage}
            disabled={currentPage === 1}
            className={`group relative w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 ${
              currentPage > 1
                ? 'bg-gray-800/60 hover:bg-gray-700/80 text-gray-300 hover:text-white border border-gray-600/30 hover:border-gray-500/50'
                : 'bg-gray-900/40 text-gray-600 cursor-not-allowed border border-gray-700/20'
            }`}
            title="Previous Page"
          >
            <ChevronLeft size={18} className="drop-shadow-sm" />
            {currentPage > 1 && (
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-blue-600/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            )}
          </button>
          
          {/* Page Indicator */}
          <div className="bg-gradient-to-r from-gray-800/80 to-gray-700/80 backdrop-blur-sm rounded-xl px-4 py-2 min-w-[80px] text-center border border-gray-600/30">
            <div className="flex flex-col items-center space-y-0.5">
              <span className="text-xs text-gray-400 font-medium uppercase tracking-wider">
                Page
              </span>
              <span className="text-lg text-white font-bold drop-shadow-sm">
                {currentPage}
              </span>
            </div>
          </div>
          
          {/* Next Page */}
          <button
            onClick={onNextPage}
            className="group relative w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 bg-gray-800/60 hover:bg-gray-700/80 text-gray-300 hover:text-white border border-gray-600/30 hover:border-gray-500/50"
            title="Next Page"
          >
            <ChevronRight size={18} className="drop-shadow-sm" />
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-blue-600/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
        </div>
      </div>
    </div>
  );
};