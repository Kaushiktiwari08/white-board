import React, { useState } from 'react';
import { 
  Plus, 
  Download, 
  Share, 
  User, 
  ChevronDown,
  FileText,
  Trash2,
  MoreHorizontal,
  FileDown,
  LogIn,
  LogOut,
  Maximize
} from 'lucide-react';
import { WhiteboardPage } from '../types';
import { SignInModal } from './SignInModal';

interface TopBarProps {
  pages: WhiteboardPage[];
  currentPageIndex: number;
  onAddPage: (insertIndex?: number) => void;
  onDeletePage: (pageIndex: number) => void;
  onSwitchPage: (pageIndex: number) => void;
  onExport: (format?: 'png' | 'pdf') => void;
  onToggleFullscreen: () => void;
  canExport: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  pages,
  currentPageIndex,
  onAddPage,
  onDeletePage,
  onSwitchPage,
  onExport,
  onToggleFullscreen,
  canExport
}) => {
  const [showPageMenu, setShowPageMenu] = useState(false);
  const [showPageOptions, setShowPageOptions] = useState<number | null>(null);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showSignInModal, setShowSignInModal] = useState(false);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);

  const handleSignIn = (email: string, password: string) => {
    // Simulate user sign in
    setUser({
      name: email.split('@')[0], // Use part before @ as name
      email: email
    });
  };

  const handleSignOut = () => {
    setUser(null);
    setShowProfileMenu(false);
  };

  return (
    <div className="fixed top-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-sm border-b border-gray-200">
      <div className="flex items-center justify-between px-3 md:px-6 py-3 md:py-4">
        {/* Logo */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
              <FileText size={16} className="text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg md:text-xl font-semibold text-gray-800 leading-tight">Whiteboard</span>
              <span className="text-xs text-gray-500 leading-none hidden md:block">
                Digital Canvas
              </span>
            </div>
          </div>
        </div>

        {/* Pages Section */}
        <div className="flex items-center space-x-2 md:space-x-4">
          {/* Page Navigation */}
          <div className="flex items-center space-x-2">
            <div className="relative">
              <button
                onClick={() => setShowPageMenu(!showPageMenu)}
                className="flex items-center space-x-2 px-3 md:px-4 py-2 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors duration-200 touch-manipulation"
                style={{ WebkitTapHighlightColor: 'transparent' }}
              >
                <span className="text-sm font-medium text-gray-700">
                  {pages[currentPageIndex]?.name || 'Page 1'}
                </span>
                <ChevronDown size={14} className="text-gray-500" />
              </button>
              
              {showPageMenu && (
                <div className="absolute top-full left-0 mt-2 w-56 md:w-64 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-50">
                  <div className="px-3 py-2 border-b border-gray-100">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Pages</span>
                      <button
                        onClick={() => {
                          onAddPage();
                          setShowPageMenu(false);
                        }}
                        className="p-1 hover:bg-gray-100 rounded-md transition-colors duration-200 touch-manipulation"
                        style={{ WebkitTapHighlightColor: 'transparent' }}
                      >
                        <Plus size={14} className="text-gray-600" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="max-h-64 overflow-y-auto">
                    {pages.map((page, index) => (
                      <div
                        key={page.id}
                        className={`group flex items-center justify-between px-3 py-2 cursor-pointer transition-colors duration-200 touch-manipulation ${
                          index === currentPageIndex ? 'bg-blue-50' : 'hover:bg-gray-50'
                        }`}
                        onClick={() => {
                          onSwitchPage(index);
                          setShowPageMenu(false);
                        }}
                        style={{ WebkitTapHighlightColor: 'transparent' }}
                      >
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full" />
                          <span className={`text-sm ${
                            index === currentPageIndex ? 'text-blue-600 font-medium' : 'text-gray-700'
                          }`}>
                            {page.name}
                          </span>
                        </div>
                        
                        {pages.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setShowPageOptions(showPageOptions === index ? null : index);
                            }}
                            className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 rounded-md transition-all duration-200 touch-manipulation"
                            style={{ WebkitTapHighlightColor: 'transparent' }}
                          >
                            <MoreHorizontal size={12} className="text-gray-500" />
                          </button>
                        )}
                        
                        {showPageOptions === index && (
                          <div className="absolute right-2 top-full mt-1 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-10">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onAddPage(index + 1);
                                setShowPageOptions(null);
                              }}
                              className="w-full text-left px-3 py-1 text-sm text-gray-700 hover:bg-gray-50 flex items-center space-x-2 touch-manipulation"
                              style={{ WebkitTapHighlightColor: 'transparent' }}
                            >
                              <Plus size={12} />
                              <span>Insert After</span>
                            </button>
                            {page.id !== 'page-1-default' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onDeletePage(index);
                                  setShowPageOptions(null);
                                }}
                                className="w-full text-left px-3 py-1 text-sm text-red-600 hover:bg-red-50 flex items-center space-x-2 touch-manipulation"
                                style={{ WebkitTapHighlightColor: 'transparent' }}
                              >
                                <Trash2 size={12} />
                                <span>Delete</span>
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <button
              onClick={() => onAddPage()}
              className="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors duration-200 touch-manipulation"
              title="Add New Page"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <Plus size={16} />
            </button>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-2 md:space-x-3">
          {/* Desktop Export Button */}
          <div className="hidden md:block">
            <button
              onClick={() => onExport('pdf')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors duration-200 touch-manipulation ${
                canExport 
                  ? 'bg-gray-50 hover:bg-gray-100' 
                  : 'bg-gray-100 cursor-not-allowed opacity-50'
              }`}
              disabled={!canExport}
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <FileDown size={16} className="text-gray-600" />
              <span className="text-sm font-medium text-gray-700">Save as PDF</span>
            </button>
          </div>
          
          {/* Desktop Fullscreen Button */}
          <div className="hidden md:block">
            <button
              onClick={onToggleFullscreen}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors duration-200 touch-manipulation"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <Maximize size={16} className="text-white" />
              <span className="text-sm font-medium text-white">Fullscreen</span>
            </button>
          </div>
          
          {/* Mobile Export Button */}
          <div className="md:hidden">
            <button
              onClick={() => onExport('pdf')}
              className={`p-2 rounded-lg transition-colors duration-200 touch-manipulation ${
                canExport 
                  ? 'bg-gray-50 hover:bg-gray-100' 
                  : 'bg-gray-100 cursor-not-allowed opacity-50'
              }`}
              disabled={!canExport}
              title="Save as PDF"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <FileDown size={16} className="text-gray-600" />
            </button>
          </div>
          
          {/* Mobile Fullscreen Button */}
          <div className="md:hidden">
            <button
              onClick={onToggleFullscreen}
              className="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors duration-200 touch-manipulation"
              title="Fullscreen"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              <Maximize size={16} className="text-white" />
            </button>
          </div>
          
          <button className="hidden md:flex items-center space-x-2 px-4 py-2 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors duration-200 touch-manipulation"
            style={{ WebkitTapHighlightColor: 'transparent' }}>
            <Share size={16} className="text-gray-600" />
            <span className="text-sm font-medium text-gray-700">Share</span>
          </button>
          
          {/* Mobile Share Button */}
          <button className="md:hidden p-2 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors duration-200 touch-manipulation"
            title="Share"
            style={{ WebkitTapHighlightColor: 'transparent' }}>
            <Share size={16} className="text-gray-600" />
          </button>
          
          <div className="relative">
            <button 
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className="flex items-center space-x-2 p-2 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors duration-200 touch-manipulation"
              style={{ WebkitTapHighlightColor: 'transparent' }}
            >
              {user ? (
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium text-white">
                      {user.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <span className="text-sm font-medium text-gray-700 hidden md:block">
                    {user.name}
                  </span>
                </div>
              ) : (
                <User size={16} className="text-gray-600" />
              )}
            </button>
            
            {showProfileMenu && (
              <div className="absolute top-full right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-50">
                {user ? (
                  <>
                    <div className="px-4 py-3 border-b border-gray-100">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-white">
                            {user.name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800">{user.name}</div>
                          <div className="text-sm text-gray-500">{user.email}</div>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={handleSignOut}
                      className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center space-x-3 touch-manipulation"
                      style={{ WebkitTapHighlightColor: 'transparent' }}
                    >
                      <LogOut size={16} />
                      <span>Sign Out</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => {
                      setShowSignInModal(true);
                      setShowProfileMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center space-x-3 touch-manipulation"
                    style={{ WebkitTapHighlightColor: 'transparent' }}
                  >
                    <LogIn size={16} />
                    <span>Sign In</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      
      <SignInModal
        isOpen={showSignInModal}
        onClose={() => setShowSignInModal(false)}
        onSignIn={handleSignIn}
      />
    </div>
  );
};