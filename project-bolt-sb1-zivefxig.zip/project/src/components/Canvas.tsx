import React from 'react';
import { WhiteboardPage, Tool } from '../types';
import { useCanvas } from '../hooks/useCanvas';

interface CanvasProps {
  currentPage: WhiteboardPage;
  tool: Tool;
  onUpdatePage: (page: WhiteboardPage) => void;
  onExportReady?: (exportFn: () => string) => void;
}

export const Canvas: React.FC<CanvasProps> = ({ 
  currentPage, 
  tool, 
  onUpdatePage,
  onExportReady 
}) => {
  const { canvasRef } = useCanvas(currentPage, tool, onUpdatePage);

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      // Force redraw after resize
      setTimeout(() => {
        // Trigger a redraw by updating a dummy state or calling redraw directly
        const event = new CustomEvent('canvasResized');
        canvas.dispatchEvent(event);
      }, 50);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Listen for fullscreen changes to trigger redraw
    const handleFullscreenChange = () => {
      setTimeout(() => {
        resizeCanvas();
      }, 100);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
    };
  }, []);

  React.useEffect(() => {
    if (onExportReady && canvasRef.current) {
      const exportFn = () => {
        return canvasRef.current?.toDataURL('image/png') || '';
      };
      onExportReady(exportFn);
    }
  }, [onExportReady, canvasRef]);

  const backgroundClass = {
    white: 'bg-white',
    black: 'bg-gray-900',
    grid: 'bg-white'
  }[currentPage.background];

  return (
    <div className={`fixed inset-0 ${backgroundClass}`}>
      <style jsx>{`
        @keyframes highlighter-glow {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.6; }
        }
        .highlighter-glow {
          animation: highlighter-glow 2s ease-in-out infinite;
        }
      `}</style>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 cursor-crosshair touch-none select-none"
        style={{ 
          touchAction: 'none',
          WebkitTouchCallout: 'none',
          WebkitUserSelect: 'none',
          userSelect: 'none'
        }}
      />
    </div>
  );
};