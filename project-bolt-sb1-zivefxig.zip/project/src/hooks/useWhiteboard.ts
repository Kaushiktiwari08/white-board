import { useState, useEffect, useCallback } from 'react';
import { WhiteboardPage, CanvasState, Tool } from '../types';

const STORAGE_KEY = 'whiteboard-data';

// Validate a page object
function isValidPage(page: any): page is WhiteboardPage {
  return (
    page &&
    typeof page === 'object' &&
    typeof page.id === 'string' &&
    typeof page.name === 'string' &&
    Array.isArray(page.paths) &&
    Array.isArray(page.texts) &&
    Array.isArray(page.shapes) &&
    (page.background === 'white' || page.background === 'black' || page.background === 'grid') &&
    typeof page.timestamp === 'number'
  );
}

// Load pages from localStorage with validation
function loadWhiteboardState(): CanvasState {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      const loaded = JSON.parse(saved);
      // Validate the loaded state
      if (loaded && 
          Array.isArray(loaded.pages) && 
          loaded.pages.length > 0 &&
          loaded.pages.every(isValidPage) &&
          typeof loaded.currentPageIndex === 'number' &&
          loaded.currentPageIndex >= 0 &&
          loaded.currentPageIndex < loaded.pages.length) {
        return loaded;
      }
    } catch (e) {
      console.error('Failed to parse whiteboard data:', e);
    }
  }
  // If no valid data, return initial state
  return initialState;
}

const createNewPage = (name: string = 'New Page'): WhiteboardPage => ({
  id: Date.now().toString(),
  name,
  paths: [],
  texts: [],
  shapes: [],
  background: 'white',
  timestamp: Date.now()
});

const initialState: CanvasState = {
  pages: [{ ...createNewPage('Page 1'), id: 'page-1-default' }],
  currentPageIndex: 0,
  history: [],
  historyIndex: -1
};

export const useWhiteboard = () => {
  const [state, setState] = useState<CanvasState>(initialState);
  const [tool, setTool] = useState<Tool>({
    type: 'pen',
    color: '#000000',
    width: 2,
    fontSize: 16
  });

  // Load from localStorage on mount
  useEffect(() => {
    const loadedState = loadWhiteboardState();
    setState(loadedState);
  }, []);

  // Save to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const currentPage = state.pages[state.currentPageIndex];

  const updateCurrentPage = useCallback((page: WhiteboardPage) => {
    setState(prev => {
      const newPages = [...prev.pages];
      newPages[prev.currentPageIndex] = page;
      
      // Add to history for undo/redo
      const newHistory = prev.history.slice(0, prev.historyIndex + 1);
      newHistory.push([...newPages]);
      
      return {
        ...prev,
        pages: newPages,
        history: newHistory,
        historyIndex: newHistory.length - 1
      };
    });
  }, []);

  const addPage = useCallback((insertIndex?: number) => {
    const newPage = {
      ...createNewPage(`Page ${state.pages.length + 1}`),
      background: currentPage.background // Inherit background from current page
    };
    setState(prev => {
      const newPages = [...prev.pages];
      const index = insertIndex !== undefined ? insertIndex : prev.pages.length;
      newPages.splice(index, 0, newPage);
      
      return {
        ...prev,
        pages: newPages,
        currentPageIndex: index
      };
    });
  }, [state.pages.length, currentPage.background]);

  const deletePage = useCallback((pageIndex: number) => {
    // Prevent deletion of Page 1 (default page) and if it's the only page
    if (state.pages.length <= 1 || state.pages[pageIndex].id === 'page-1-default') return;
    
    setState(prev => {
      const newPages = prev.pages.filter((_, index) => index !== pageIndex);
      let newCurrentIndex = prev.currentPageIndex;
      
      if (pageIndex === prev.currentPageIndex) {
        newCurrentIndex = Math.min(pageIndex, newPages.length - 1);
      } else if (pageIndex < prev.currentPageIndex) {
        newCurrentIndex = prev.currentPageIndex - 1;
      }
      
      return {
        ...prev,
        pages: newPages,
        currentPageIndex: newCurrentIndex
      };
    });
  }, [state.pages.length]);

  const switchPage = useCallback((pageIndex: number) => {
    // If trying to go to a page that doesn't exist, create pages up to that index
    if (pageIndex >= state.pages.length) {
      setState(prev => {
        const newPages = [...prev.pages];
        // Create pages up to the requested index
        for (let i = prev.pages.length; i <= pageIndex; i++) {
          newPages.push(createNewPage(`Page ${i + 1}`));
        }
        return {
          ...prev,
          pages: newPages,
          currentPageIndex: pageIndex
        };
      });
    } else {
    setState(prev => ({
      ...prev,
      currentPageIndex: pageIndex
    }));
    }
  }, []);

  const goToNextPage = useCallback(() => {
    const nextIndex = state.currentPageIndex + 1;
    switchPage(nextIndex); // This will auto-create the page if it doesn't exist
  }, [state.currentPageIndex, switchPage]);

  const goToPreviousPage = useCallback(() => {
    if (state.currentPageIndex > 0) {
      switchPage(state.currentPageIndex - 1);
    }
  }, [state.currentPageIndex, switchPage]);

  const undo = useCallback(() => {
    if (state.historyIndex > 0) {
      setState(prev => ({
        ...prev,
        pages: prev.history[prev.historyIndex - 1],
        historyIndex: prev.historyIndex - 1
      }));
    }
  }, [state.historyIndex]);

  const redo = useCallback(() => {
    if (state.historyIndex < state.history.length - 1) {
      setState(prev => ({
        ...prev,
        pages: prev.history[prev.historyIndex + 1],
        historyIndex: prev.historyIndex + 1
      }));
    }
  }, [state.historyIndex, state.history.length]);

  const clearPage = useCallback(() => {
    const clearedPage = {
      ...currentPage,
      paths: [],
      texts: [],
      shapes: []
    };
    updateCurrentPage(clearedPage);
  }, [currentPage, updateCurrentPage]);

  const changeBackground = useCallback((background: 'white' | 'black' | 'grid') => {
    const updatedPage = {
      ...currentPage,
      background
    };
    updateCurrentPage(updatedPage);
  }, [currentPage, updateCurrentPage]);

  const exportAsImage = useCallback(async (format: 'png' | 'jpg' = 'png') => {
    // This will be implemented with the canvas reference
    return null;
  }, []);

  return {
    state,
    currentPage,
    tool,
    setTool,
    updateCurrentPage,
    addPage,
    deletePage,
    switchPage,
    undo,
    redo,
    clearPage,
    changeBackground,
    exportAsImage,
    goToNextPage,
    goToPreviousPage,
    canUndo: state.historyIndex > 0,
    canRedo: state.historyIndex < state.history.length - 1
  };
};