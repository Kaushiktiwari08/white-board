import { useRef, useEffect, useState, useCallback } from 'react';
import { Point, DrawingPath, TextElement, ShapeElement, WhiteboardPage, Tool } from '../types';

export const useCanvas = (
  currentPage: WhiteboardPage,
  tool: Tool,
  onUpdatePage: (page: WhiteboardPage) => void
) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<Point[]>([]);
  const [isCreatingShape, setIsCreatingShape] = useState(false);
  const [shapeStart, setShapeStart] = useState<Point | null>(null);
  const [tempShape, setTempShape] = useState<ShapeElement | null>(null);

  const getCanvasPoint = useCallback((e: MouseEvent | TouchEvent): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    
    let clientX: number, clientY: number;
    
    if ('touches' in e) {
      // Handle touch events
      if (e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if (e.changedTouches && e.changedTouches.length > 0) {
        // For touchend events, use changedTouches
        clientX = e.changedTouches[0].clientX;
        clientY = e.changedTouches[0].clientY;
      } else {
        return { x: 0, y: 0 };
      }
    } else {
      // Handle mouse events
      clientX = e.clientX;
      clientY = e.clientY;
    }

    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  }, []);

  const drawPath = useCallback((ctx: CanvasRenderingContext2D, path: DrawingPath) => {
    if (path.points.length === 0) return;

    ctx.beginPath();
    ctx.strokeStyle = path.color;
    ctx.lineWidth = path.width;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (path.tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
    } else if (path.tool === 'highlighter') {
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = 0.3;
      
      // Add glow effect for highlighter
      ctx.shadowColor = path.color;
      ctx.shadowBlur = 8;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
    }

    ctx.moveTo(path.points[0].x, path.points[0].y);
    for (let i = 1; i < path.points.length; i++) {
      ctx.lineTo(path.points[i].x, path.points[i].y);
    }
    ctx.stroke();
    
    // Reset context properties
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
  }, []);

  const drawText = useCallback((ctx: CanvasRenderingContext2D, text: TextElement) => {
    ctx.fillStyle = text.color;
    ctx.font = `${text.fontSize}px Inter, sans-serif`;
    ctx.textBaseline = 'top';
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillText(text.text, text.x, text.y);
  }, []);

  const drawShape = useCallback((ctx: CanvasRenderingContext2D, shape: ShapeElement) => {
    ctx.strokeStyle = shape.color;
    ctx.lineWidth = shape.strokeWidth;
    ctx.globalCompositeOperation = 'source-over';

    if (shape.filled) {
      ctx.fillStyle = shape.color;
    }

    if (shape.type === 'rectangle') {
      if (shape.filled) {
        ctx.fillRect(shape.x, shape.y, shape.width, shape.height);
      } else {
        ctx.strokeRect(shape.x, shape.y, shape.width, shape.height);
      }
    } else if (shape.type === 'circle') {
      const centerX = shape.x + shape.width / 2;
      const centerY = shape.y + shape.height / 2;
      const radius = Math.min(Math.abs(shape.width), Math.abs(shape.height)) / 2;
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
      
      if (shape.filled) {
        ctx.fill();
      } else {
        ctx.stroke();
      }
    }
  }, []);

  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Set white background for exports (especially important for PDF)
    ctx.fillStyle = currentPage.background === 'black' ? '#1f2937' : '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw background
    if (currentPage.background === 'grid') {
      ctx.strokeStyle = '#f0f0f0';
      ctx.lineWidth = 1;
      const gridSize = 20;
      
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }
    }

    // Draw all paths
    currentPage.paths.forEach(path => drawPath(ctx, path));
    
    // Draw all shapes
    currentPage.shapes.forEach(shape => drawShape(ctx, shape));
    
    // Draw all text elements
    currentPage.texts.forEach(text => drawText(ctx, text));

    // Draw temporary shape if creating
    if (tempShape) {
      drawShape(ctx, tempShape);
    }
  }, [currentPage, drawPath, drawShape, drawText, tempShape]);

  const startDrawing = useCallback((e: MouseEvent | TouchEvent) => {
    const point = getCanvasPoint(e);
    
    if (tool.type === 'pen' || tool.type === 'eraser' || tool.type === 'highlighter') {
      setIsDrawing(true);
      setCurrentPath([point]);
    } else if (tool.type === 'rectangle' || tool.type === 'circle') {
      setIsCreatingShape(true);
      setShapeStart(point);
    } else if (tool.type === 'text') {
      const text = prompt('Enter text:');
      if (text) {
        const newText: TextElement = {
          id: Date.now().toString(),
          x: point.x,
          y: point.y,
          text,
          color: tool.color,
          fontSize: tool.fontSize || 16,
          timestamp: Date.now()
        };
        
        const updatedPage = {
          ...currentPage,
          texts: [...currentPage.texts, newText]
        };
        onUpdatePage(updatedPage);
      }
    }
  }, [tool, getCanvasPoint, currentPage, onUpdatePage]);

  const draw = useCallback((e: MouseEvent | TouchEvent) => {
    if (!isDrawing && !isCreatingShape) return;

    const point = getCanvasPoint(e);

    if (isDrawing) {
      setCurrentPath(prev => [...prev, point]);
    } else if (isCreatingShape && shapeStart) {
      const width = point.x - shapeStart.x;
      const height = point.y - shapeStart.y;
      
      const newShape: ShapeElement = {
        id: Date.now().toString(),
        type: tool.type as 'rectangle' | 'circle',
        x: shapeStart.x,
        y: shapeStart.y,
        width,
        height,
        color: tool.color,
        strokeWidth: tool.width,
        filled: false,
        timestamp: Date.now()
      };
      
      setTempShape(newShape);
    }
  }, [isDrawing, isCreatingShape, shapeStart, getCanvasPoint, tool]);

  const stopDrawing = useCallback(() => {
    if (isDrawing && currentPath.length > 0) {
      const newPath: DrawingPath = {
        id: Date.now().toString(),
        points: currentPath,
        color: tool.type === 'highlighter' ? '#22c55e' : tool.color, // Force light green for highlighter
        width: tool.width,
        tool: tool.type as 'pen' | 'eraser' | 'highlighter',
        timestamp: Date.now()
      };

      const updatedPage = {
        ...currentPage,
        paths: [...currentPage.paths, newPath]
      };
      onUpdatePage(updatedPage);
      setCurrentPath([]);
    }

    if (isCreatingShape && tempShape) {
      const updatedPage = {
        ...currentPage,
        shapes: [...currentPage.shapes, tempShape]
      };
      onUpdatePage(updatedPage);
      setTempShape(null);
      setShapeStart(null);
    }

    setIsDrawing(false);
    setIsCreatingShape(false);
  }, [isDrawing, isCreatingShape, currentPath, tempShape, tool, currentPage, onUpdatePage]);

  // Set up canvas event listeners
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Prevent default touch behaviors to avoid scrolling/zooming
    const preventDefaults = (e: Event) => {
      e.preventDefault();
      e.stopPropagation();
    };
    const handleMouseDown = (e: MouseEvent) => {
      e.preventDefault();
      startDrawing(e);
    };

    const handleMouseMove = (e: MouseEvent) => {
      e.preventDefault();
      draw(e);
    };

    const handleMouseUp = (e: MouseEvent) => {
      e.preventDefault();
      stopDrawing();
    };

    const handleTouchStart = (e: TouchEvent) => {
      e.preventDefault();
      // Only handle single touch to avoid multi-touch gestures
      if (e.touches.length === 1) {
      startDrawing(e);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      e.preventDefault();
      // Only handle single touch
      if (e.touches.length === 1) {
      draw(e);
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      e.preventDefault();
      stopDrawing();
    };

    // Add passive: false to ensure preventDefault works
    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
    canvas.addEventListener('touchend', handleTouchEnd, { passive: false });
    canvas.addEventListener('touchcancel', handleTouchEnd, { passive: false });
    
    // Prevent context menu on long press
    canvas.addEventListener('contextmenu', preventDefaults);
    
    // Prevent double-tap zoom
    canvas.addEventListener('dblclick', preventDefaults);

    return () => {
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
      canvas.removeEventListener('touchcancel', handleTouchEnd);
      canvas.removeEventListener('contextmenu', preventDefaults);
      canvas.removeEventListener('dblclick', preventDefaults);
    };
  }, [startDrawing, draw, stopDrawing]);

  // Redraw canvas when page changes
  useEffect(() => {
    // Small delay to ensure canvas is properly sized after fullscreen changes
    const timeoutId = setTimeout(() => {
    redrawCanvas();
    }, 50);
    
    return () => clearTimeout(timeoutId);
  }, [redrawCanvas]);

  // Force redraw when canvas dimensions change (fullscreen transitions)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeObserver = new ResizeObserver(() => {
      // Redraw after canvas resize
      setTimeout(() => {
        redrawCanvas();
      }, 100);
    });

    resizeObserver.observe(canvas);

    return () => {
      resizeObserver.disconnect();
    };
  }, [redrawCanvas]);

  // Draw current path while drawing
  useEffect(() => {
    if (isDrawing && currentPath.length > 0) {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      redrawCanvas();

      // Draw current path
      const tempPath: DrawingPath = {
        id: 'temp',
        points: currentPath,
        color: tool.type === 'highlighter' ? '#22c55e' : tool.color,
        width: tool.width,
        tool: tool.type as 'pen' | 'eraser' | 'highlighter',
        timestamp: Date.now()
      };
      drawPath(ctx, tempPath);
    }
  }, [isDrawing, currentPath, tool, redrawCanvas, drawPath]);

  return { canvasRef, redrawCanvas };
};