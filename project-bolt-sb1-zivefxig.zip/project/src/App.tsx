import React, { useState, useCallback } from 'react';
import { Canvas } from './components/Canvas';
import { TopBar } from './components/TopBar';
import { Toolbar } from './components/Toolbar';
import { FullscreenToolbar } from './components/FullscreenToolbar';
import { PageControls } from './components/PageControls';
import { useWhiteboard } from './hooks/useWhiteboard';
import jsPDF from 'jspdf';

function App() {
  const {
    state,
    currentPage,
    tool,
    setTool,
    updateCurrentPage,
    addPage,
    deletePage,
    switchPage,
    undo,
    redo,
    clearPage,
    changeBackground,
    goToNextPage,
    goToPreviousPage,
    canUndo,
    canRedo
  } = useWhiteboard();

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [exportFunction, setExportFunction] = useState<(() => string) | null>(null);

  const handleExportReady = useCallback((exportFn: () => string) => {
    setExportFunction(() => exportFn);
  }, []);

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!isFullscreen) {
        // Enter fullscreen
        setIsFullscreen(true);
        
        // Try to enter browser fullscreen
        if (document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
        } else if ((document.documentElement as any).webkitRequestFullscreen) {
          await (document.documentElement as any).webkitRequestFullscreen();
        } else if ((document.documentElement as any).mozRequestFullScreen) {
          await (document.documentElement as any).mozRequestFullScreen();
        }
      } else {
        // Exit fullscreen
        setIsFullscreen(false);
        
        // Try to exit browser fullscreen
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as any).webkitExitFullscreen) {
          await (document as any).webkitExitFullscreen();
        } else if ((document as any).mozCancelFullScreen) {
          await (document as any).mozCancelFullScreen();
        }
      }
    } catch (error) {
      console.error('Fullscreen toggle failed:', error);
      // Still update our state even if browser fullscreen fails
      setIsFullscreen(!isFullscreen);
    }
  }, [isFullscreen]);

  // Listen for fullscreen changes from browser (like pressing Escape)
  React.useEffect(() => {
    const handleFullscreenChange = () => {
      const isCurrentlyFullscreen = !!(
        document.fullscreenElement ||
        (document as any).webkitFullscreenElement ||
        (document as any).mozFullScreenElement ||
        (document as any).msFullscreenElement
      );
      
      if (!isCurrentlyFullscreen && isFullscreen) {
        setIsFullscreen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('msfullscreenchange', handleFullscreenChange);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('msfullscreenchange', handleFullscreenChange);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isFullscreen]);

  const handleExport = useCallback(async (format: 'png' | 'pdf' = 'pdf') => {
    if (!exportFunction) return;

    try {
      if (format === 'png') {
        const dataUrl = exportFunction();
        const link = document.createElement('a');
        link.download = `whiteboard-page-${state.currentPageIndex + 1}.png`;
        link.href = dataUrl;
        link.click();
      } else if (format === 'pdf') {
        const pdf = new jsPDF({
          orientation: 'landscape',
          unit: 'px',
          format: [window.innerWidth, window.innerHeight]
        });

        // Export all pages
        for (let i = 0; i < state.pages.length; i++) {
          if (i > 0) {
            pdf.addPage();
          }
          
          // Switch to page temporarily for export
          if (i !== state.currentPageIndex) {
            switchPage(i);
            // Wait a bit for the page to render
            await new Promise(resolve => setTimeout(resolve, 100));
          }
          
          const dataUrl = exportFunction();
          if (dataUrl) {
            pdf.addImage(dataUrl, 'PNG', 0, 0, window.innerWidth, window.innerHeight);
          }
        }
        
        // Switch back to original page
        if (state.currentPageIndex !== state.pages.length - 1) {
          switchPage(state.currentPageIndex);
        }
        
        pdf.save(`whiteboard-${state.pages.length}-pages.pdf`);
      }
    } catch (error) {
      console.error('Export failed:', error);
    }
  }, [exportFunction, state.pages.length, state.currentPageIndex, switchPage]);

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 bg-white">
        <Canvas
          currentPage={currentPage}
          tool={tool}
          onUpdatePage={updateCurrentPage}
          onExportReady={handleExportReady}
        />
        
        <FullscreenToolbar
          tool={tool}
          onToolChange={setTool}
          onUndo={undo}
          onRedo={redo}
          onClear={clearPage}
          onBackgroundChange={changeBackground}
          canUndo={canUndo}
          canRedo={canRedo}
          currentBackground={currentPage.background}
          onExitFullscreen={toggleFullscreen}
        />
        
        <PageControls
          isFullscreen={isFullscreen}
          currentPage={state.currentPageIndex + 1}
          onPreviousPage={goToPreviousPage}
          onNextPage={goToNextPage}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <TopBar
        pages={state.pages}
        currentPageIndex={state.currentPageIndex}
        onAddPage={addPage}
        onDeletePage={deletePage}
        onSwitchPage={switchPage}
        onExport={handleExport}
        onToggleFullscreen={toggleFullscreen}
        canExport={!!exportFunction}
      />
      
      <div className="pt-20">
        <Canvas
          currentPage={currentPage}
          tool={tool}
          onUpdatePage={updateCurrentPage}
          onExportReady={handleExportReady}
        />
        
        <Toolbar
          tool={tool}
          onToolChange={setTool}
          onUndo={undo}
          onRedo={redo}
          onClear={clearPage}
          onBackgroundChange={changeBackground}
          canUndo={canUndo}
          canRedo={canRedo}
          currentBackground={currentPage.background}
        />
        
        <PageControls
          isFullscreen={isFullscreen}
          currentPage={state.currentPageIndex + 1}
          onPreviousPage={goToPreviousPage}
          onNextPage={goToNextPage}
        />
      </div>
    </div>
  );
}

export default App;