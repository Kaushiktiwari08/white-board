export interface Point {
  x: number;
  y: number;
}

export interface DrawingPath {
  id: string;
  points: Point[];
  color: string;
  width: number;
  tool: 'pen' | 'eraser' | 'highlighter';
  timestamp: number;
}

export interface TextElement {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  fontSize: number;
  timestamp: number;
}

export interface ShapeElement {
  id: string;
  type: 'rectangle' | 'circle';
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  strokeWidth: number;
  filled: boolean;
  timestamp: number;
}

export interface WhiteboardPage {
  id: string;
  name: string;
  paths: DrawingPath[];
  texts: TextElement[];
  shapes: ShapeElement[];
  background: 'white' | 'black' | 'grid';
  timestamp: number;
}

export interface CanvasState {
  pages: WhiteboardPage[];
  currentPageIndex: number;
  history: WhiteboardPage[][];
  historyIndex: number;
}

export interface Tool {
  type: 'pen' | 'eraser' | 'text' | 'rectangle' | 'circle' | 'select' | 'highlighter';
  color: string;
  width: number;
  fontSize?: number;
}